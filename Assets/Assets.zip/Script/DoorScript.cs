using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class DoorScript : MonoBehaviourPun
{
    private int playerNum;
    private void Start()
    {
        playerNum = 3;
    }
    [PunRPC]
    private void OnCollisionEnter2D(Collision2D collision2D)
    {
        if (collision2D.gameObject.CompareTag("Player"))
        {
            playerNum--;
            PhotonNetwork.Destroy(collision2D.gameObject);
        }
        if (playerNum == 0) 
        {
            Debug.Log("END GAME");
        }
    }
    
}
